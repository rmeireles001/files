#include "propagacao.h"

//PROBLEMA DIRETO - C�LCULO DOS ECOS

void propagacao_de_onda (int op)
{
    FILE *p,*eco, *saida, *resultados;
    double  X[pontos][3], epslon, c; /* utiliza somente posicoes 1 e 2, a posicao 0 n�o � utlizada*/
    double A[pontos], z[pontos], R[pontos], dano_posicao, dano_area, F[pontos], P[pontos], G[pontos], dano[5], pontox[3], pontoy[3];
    double **A1, **QQ, **B1, **x;
    double n_aux, h, comprimento, ad, bd, ac, bc, profundidade_dano, raio, xx, xxx, polinomio;
    int i, i1, lin, p1, n1, j, j1, k, somatorio1, loop, n, numero_sinais, ent_sinal;
    
    saida=fopen("saida_ruido.txt", "w");
    if (saida==NULL) printf ("Erro, arquivo saida_ruido");
    
    resultados=fopen("resultados.txt", "w");
    if (resultados==NULL) printf ("Erro, arquivo resultados");    

    //aloca��o das linhas de cada matriz
    QQ = (double **) calloc (pontos, sizeof(double *));
    if (QQ == NULL) {
       printf ("Erro na alocacao de QQ");
       return;
     }

     A1=(double **) calloc (pontos, sizeof (double *));
     if (A1 == NULL)
     {
        printf("ERRO na alocacao de A1");
        return;
      }

      B1=(double **) calloc (pontos, sizeof (double *));
      if (B1 == NULL)
      {
        printf("ERRO na alocacao de B1!");
        return;
      }

     x=(double **) calloc (pontos, sizeof (double *)); //MATRIZ X - RELATIVA AOS DANOS
     if (x == NULL)
     {
        printf("ERRO na alocacao de x!");
        return;
      }


  /* aloca as colunas da matriz */
     for ( i = 0; i < pontos; i++ )
     {
     QQ[i] = (double*) calloc (pontos, sizeof(double));
     if (QQ[i] == NULL)
     {
        printf ("Erro na alocacao de QQ");
        return;
      }
     }

     for ( i = 0; i < pontos; i++ )
     {
     A1[i] = (double*) calloc (pontos, sizeof(double));
     if (A1[i] == NULL)
     {
        printf ("Erro na alocacao de A1");
        return;
      }
     }

     for ( i = 0; i < pontos; i++ )
     {
     B1[i] = (double*) calloc (pontos, sizeof(double));
     if (B1[i] == NULL)
     {
        printf ("Erro na alocacao de B1");
        return;
      }
     }

     for ( i = 0; i < pontos; i++ )
     {
     x[i] = (double*) calloc (pontos, sizeof(double));
     if (x[i] == NULL)
     {
        printf ("Erro na alocacao de x");
        return;
      }
     }

     // Zerando matrizes
     for (i=0; i<pontos; i++)
     {
         for (j=0; j<pontos; j++)
         {
             QQ[i][j]=0.0;
             A1[i][j]=0.0;
             B1[i][j]=0.0;
             x[i][j]=0.0;
         }
     }

         
    // leitura do arquivo de entrada
    p=fopen("areas.txt", "r");
    if (p==NULL)
       printf ("Erro! Arquivo de entrada - problema direto. Reinicie o programa.\n");
    else {
            for (lin=1; lin<pontos; lin++) {
                fscanf(p,"%lf %lf", &X[lin][1],&X[lin][2]); /*transfere do arq p matriz*/
            }
    }
    fclose(p);

    c=VEL;
    
    for (i=0; i<pontos; i++)
    {
        G[i]=0.0;
        A[i]=LARG*X[i][2];
        z[i]=A[i]*RO*VEL;
    }
    z[0]=z[1];

    for (i=1; i<pontos; i++){

        R[i]=(z[i]-z[i-1])/(z[i]+z[i-1]);
    }

//Inicializa��o das duas primeiras posi��es de P
    P[1]=0.0;
    P[2]=0.0;

//Preenchimento de F
    for (i=0; i<pontos; i++)
        F[i]=0.0;

    F[1]=1.0; // pulso unit�rio - delta de dirac


    for (i=0;i<pontos;i++)
        G[i]=0.0;

//C�lculo G[1]
    for (n1=1;n1<=1; n1++)
    {
	   for (p1=1; p1<=n1-2; p1++)
           P[n1] = P[n1] + QQ[p1][n1];

       G[1] = ((G[1] + (R[n1]+ P[n1]) * F[1-n1+1]));
    }



//C�lculo G[2]
   for(n1=1; n1<=2;n1++)
   {
      for (p1=1; p1<=n1-2; p1++)
          P[n1] = P[n1] + QQ[p1][n1];

      G[2] = ((G[2] + (R[n1]+ P[n1]) * F[2-n1+1]));
    }



for (n1=3; n1<pontos; n1++)
{


	for (p1=1; p1<=n1-2; p1++)
	{
		if (p1<=(n1-3)) A1[p1][n1]=A1[p1][n1-2] - B1[p1][n1-2];

		A1[n1-2][n1-1]=0;
		somatorio1=0;

		for (k=1;k<=p1-1;k++)
		{
			somatorio1=somatorio1+QQ[k][n1-1];
		}

       	B1[p1][n1-1]=R[n1-p1-1]*(somatorio1+R[n1-1]);
		QQ[p1][n1]=R[n1-p1]*(A1[p1][n1-1]-B1[p1][n1-1]);
		P[n1]=P[n1]+QQ[p1][n1];
	}
}

   eco=fopen("eco.txt", "w");  
   

// C�lculo do eco G(j)
   for (j=1; j<pontos; j++)
   {

       for (n1=1; n1<=j; n1++)
           G[j] = G[j]+ ((R[n1]+P[n1]) * F[j-n1+1]);

       fprintf (eco, "%d \t\t\t %3.15lf \t\t\t %.15e\n", j, (2.0*(X[j][1]/1000.0)/VEL)*1000000, G[j]);       
   }
   
   printf ("\n Dados inseridos com sucesso! \n");
   system("pause");


if (op==2)
{
 //RU�DO

 n=1000;
 numero_sinais=1;

 /*for (i=1;i<pontos;i++)
 {
     fprintf (saida, "%d \t\t\t %3.15lf \t\t\t %.15e\n", j, (2.0*(X[j][1]/1000.0)/VEL)*1000000, G[j]);       
     fprintf (saida, "%3.15lf \t\t\t %.15e \n", (2.0*(X[i][1]/1000.0)/VEL)*1000000, F[i]);    
 }*/
 
 //DANO 1
// epslon=0.001388; //10dB para dano1
 //epslon=0.00043895; //20dB para dano1
 //epslon=0.0001387; //30dB para dano1

 //DANO 3
 //epslon=0.0056; //0dB para dano3
 epslon=0.00181771; //10dB para dano3
 //epslon=0.0005748; //20dB para dano3
 //epslon=0.000181; //30dB para dano3

 //DANO 4 
 //epslon=0.03214; //0dB para dano4 
 //epslon=0.0101636; //10dB para dano4
 //epslon=0.003214095; //20dB para dano4
 //epslon=0.0010163863; //30dB para dano4

 system ("cls");
 printf ("\n Ruido \n");
 ruido(G,n,epslon,numero_sinais,2);

//ORIGINAL
/*
do j=1,n,1
	!divide por 1000 pra passar para (metros)
	!multipliquei por 1000000 pra passar pra (micro segundo)
	write(resultados,*) ( (2*(x(1,j)/1000))/c )*1000000,G(j)
	!write(resultados,*) x(1,j),G(j)
	!print*,c
	!pause
end do
*/

for (j=1;j<pontos;j++)
    fprintf (resultados, "%3.15lf \t\t\t %.15e \n", (2.0*(X[j][1]/1000.0)/VEL)*1000000.0, G[j]);
    
 system ("pause");

}

fclose(eco);
fclose (saida);
fclose (resultados);

}


