#include "propagacao.h"

void LJ(int fDimension, int posicao[],double oldConfig[],double newConfig[],double A[],double E,double ro,double Gexp[],int inicio,int fim,int laco,double G[],int ponto_inicio1,int custo)
{
    double mini[500], maxi[500], Rr[500], r[500],eps,aux1,aux2,aux1ant,qbest,t1,condicao, randomico;
    int n_in,i, j, k, it, n_out,PAROU, aux, atrib, x;

    FILE *resultados, *arq_custo;

    arq_custo=fopen("custo_inverso.txt", "w");
    if (arq_custo==NULL)
        printf("Erro! Arquivo 'custo_inverso.txt'. \n");
 
    resultados=fopen("areas_finais.txt", "w");
    if (resultados==NULL)
        printf("ERRO! Arquivo 'areas_finais.txt' \n");       
    
    for(i=0;i<500;i++)
    {
        Rr[i]=0.0;
        G[i]=0.0;
    }


// defining the parameters

    n_out =100; //---- n�o usado nessa implementa��o
    n_in = 100;
    eps = 0.05;


// initial search size r

    for (i=inicio; i<=fim; i++)
    {
        mini[i] = 0.0;
        maxi[i] = 1.0;
    }

    for (k=inicio; k<=fim; k++)
    {
        r[k] = maxi[k]- mini[k];
    }

    srand((unsigned)time(NULL));

// initial guess
    for (k=inicio; k<=fim; k++)
    {
        randomico=myrand;
        oldConfig[k] = mini[k]+((maxi[k]-mini[k])*randomico);
    }

// main

    aux1=1000;
    qbest=1000;
    i=1.0;

    condicao=pow(10, -10);

while (qbest>condicao)
{
    //aux1ant=aux1;
    for (j=1;j<=n_in;j++)
    {
        for (k=inicio;k<=fim;k++)
        {
            // R(k).r(k) : R are random numbers in the interval [-0.5, 0.5];
            randomico=myrand;
			Rr[k] = ((-0.5 + randomico)*(r[k]));
			newConfig[k] = oldConfig[k] + Rr[k];

			if (newConfig[k]<mini[k])
                newConfig[k] = mini[k];

			if (newConfig[k]>maxi[k])
				newConfig[k] = maxi[k];
       }

		//if ((Q(newConfig,fDimension,mcap2p1,mcap,mcap2,ncap,dadexp))<(Q(oldConfig,fDimension,mcap2p1,mcap,mcap2,ncap,dadexp)))

//system("pause");

        aux1 =  Q(newConfig,fDimension,A,E,ro,Gexp,inicio,fim,G,custo);
        custo=custo+1;
        aux2 =	Q(oldConfig,fDimension,A,E,ro,Gexp,inicio,fim,G,custo);
        custo=custo+1;

		if (aux1<aux2)
		{
            qbest=aux1;

		    for (atrib=inicio;atrib<=fim;atrib++)
		    {
                    oldConfig[atrib] = newConfig[atrib];
		    }

		}

    }


//    printf("%d \n", i);

	//if(aux1==aux1ant)
		PAROU=PAROU+1;
	//	("%d -----PAROU /t %d",i, PAROU);
	//	fprintf(resultados, "%d --------PAROU %d", i, PAROU);

		//if(PAROU>=5)	GOTO 1200 
        //else
        //	PAROU=0
    //printf ("Inserindo dados nos arquivos: \n");
    //printf (" 'resultadofinal_inverso.txt', 'custo_inverso.txt' e 'saida_inverso.txt' \n \n");
    //printf ("Este processo pode ser um pouco demorado. \n");
    //printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n");
    //printf("\n Iteracao %d ------Laco %d \n", i, laco);
    //fprintf(resultados, "Iteracao %d ------Laco %d \n", i, laco);

    //system("pause");

//    for (it=ponto_inicio1; it<=fim;it++)
//        fprintf (resultados, "%d  %lf \n", posicao[it-2], oldConfig[it]);
        
//    fprintf(resultados, "Funcao custo: %lf \n", qbest);
//    fprintf(resultados, "------------------- \n");
    i=i+1;

	//if(qbest==0.0) goto 1200;

    for (k=inicio; k<=fim; k++)
        r[k] = ((1 - eps)*(r[k]));
        
        //system("cls");

}    

     fclose(resultados);

//continue;

fprintf(arq_custo, "\t %d \t %lf \t %d \t %d \n", custo, qbest, inicio, fim);
/*printf ("Inserindo dados nos arquivos: \n");
printf (" 'resultadofinal_inverso.txt', 'custo_inverso.txt' e 'saida_inverso.txt' \n \n");
printf ("Este processo pode ser um pouco demorado. \n");
printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n");
printf("\t %d \t %lf \t %d \t %d \n", custo, qbest, inicio, fim);
system("cls");*/
fclose (arq_custo);
}
