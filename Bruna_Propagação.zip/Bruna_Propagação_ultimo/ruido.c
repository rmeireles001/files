#include "propagacao.h"

void ruido (double Gexp[], int n, double epslon, int numero_sinais, int ent_sinal)
{
    int i,k;
    double aux[n],aux2[n], ruido[n],energia_ruido,media_ruido,energia_sinal,ruido_db,media[n],Gr[n], randomico, auxx;
    FILE *saidaexp;

    saidaexp=fopen ("saidaexp_ruido.txt", "w");
    if (saidaexp==NULL)
       printf ("Erro no arquivo saidaexp");
           
//    printf ("Parametros passados dados_exp: %d \t %lf \t %d \t %d \n", n, epslon, numero_sinais, ent_sinal);
 //   system ("pause");
//    for (i=1;i<=n;i++)
//        fprintf (saidaexp,"G: %.17e \n", Gexp[i]);
    
//    system ("pause");
       
    for (i=1;i<=n;i++)
    {
        media[i]=0;
        ruido[i]=0;
    }

    ruido_db=0;
        
    for (k=1;k<=numero_sinais;k++) // media do sinal
    {
        
        //srand(time(NULL));
        //calculando ruido
        for (i=1;i<=n;i++)
        {
            randomico=myrand;
            auxx=(myrand*2)-1;
            //printf ("%.15e \n", myrand);
            ruido[i] = epslon*auxx;
//            ruido[i] = epslon * (((rand()%MAX)*2)-1);
           // printf ("%.15e \n", (rand()%MAX));
 //           system("pause");
  //          fprintf (saidaexp, "Ruido: %lf \n", ruido[i]);
        }
        
        //calculando energia do ruido, energia do sinal e media do ruido
        energia_ruido=0;
        energia_sinal=0;
        media_ruido=0;
        
        for (i=1;i<=n;i++)        
        {
            aux[i]=ruido[i]*ruido[i];
//            fprintf (saidaexp, "Ruido ao quadrado: %lf \n", aux[i]);
            aux2[i]=Gexp[i]*Gexp[i];
            //fprintf (saidaexp, "Eco ao quadrado: %lf \n", aux2[i]);
        }
        
        for (i=1;i<=n;i++)
        {
        	energia_ruido = energia_ruido+aux[i];
         	energia_sinal = energia_sinal+aux2[i];
         	//printf ("Energia sinal= %lf \n", energia_sinal); ENERGIA SINAL OK!!!!
          	media_ruido = media_ruido + ruido[i];
        }
        
        media_ruido = media_ruido/n;
        energia_ruido=energia_ruido/n;
        energia_sinal=energia_sinal/n;
        
        if (epslon!=0) ruido_db=10*log10(energia_sinal/energia_ruido);
        
     //   printf ("TESTE LOG: %lf \n", log10(energia_sinal/energia_ruido)); 
        
        printf ("Energia_sinal %.16e \t energia_ruido %.16e \n", energia_sinal, energia_ruido);
        
        printf ("Ruido %lf db \n", ruido_db);
        if (epslon!=0) printf ("Relacao S/N (divisao) %.16e \n", energia_sinal/energia_ruido);
        
        printf ("Faixa de ruido + - %.16e \n", epslon);
        printf ("Media ruido %.16e \n", media_ruido);
        printf ("energia ruido %.16e \n", energia_ruido);
        printf ("energia sinal %.16e \n\n\n", energia_sinal);
        
        fprintf (saidaexp, "Ruido %lf db \n", ruido_db);
        if (epslon!=0) fprintf (saidaexp, "Relacao S/N (divisao) %lf \n", energia_sinal/energia_ruido);
        fprintf (saidaexp, " Faixa de ruido + - %lf \n", epslon);
        fprintf (saidaexp, "Media de ruido %lf \n", media_ruido);
        fprintf (saidaexp, "Energia do ruido %lf \n", energia_ruido);
        fprintf (saidaexp, "Energia do sinal %lf \n \n", energia_sinal);
        
        for (i=1;i<=n;i++)
        {
            Gr[i]=Gexp[i]+ruido[i];
            media[i]=media[i]+Gr[i];
        }
    }//fim media do sinal


    for (i=1;i<=n;i++)
        media[i]=media[i]/numero_sinais;
    
    fprintf (saidaexp, "---Sinal--------------------Ruido-----------------Sinal+Ruido----- \n");
    
    //Acrescentar ruido calculado******************
    for (i=1;i<=n;i++)
    {
        Gr[i]=media[i];
        fprintf (saidaexp, "%.16e \t\t %.16e \t\t %.16e \n", Gexp[i], ruido[i], Gr[i]);
        Gexp[i]=Gr[i];
    }
    
    fclose (saidaexp);
    
}//end subrotina
