#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#define VEL 5128.0
#define LARG 30.0 /*em mm*/
#define RO 2700.0
#define pontos 1001 //discretiza��o
#define ALTURA 10.0
#define myrand ((double)(rand())/(double)(RAND_MAX)) //macro
#define MAX 2
void propagacao_de_onda (int op);
void prop_onda (double G[],double A[], double E, double ro, int n, double divisor); 
void prob_inv_LJ(int n, int posicao[], double oldConfig[], int ponto_inicio1, int fim, int inicio1);
void estimativa_inicial (double A[], double E, double ro, int n, int estimativainicial);
void dados_experimentais (double Gexp[], int n, double ponderacao, int posicao[], int inicio1);
void LJ (int fDimension, int posicao[], double oldConfig[],double newConfig[], double A[],double E,double ro,double Gexp[],int inicio,int fim,int laco,double G[],int ponto_inicio1,int custo);
double Q(double config[],int fDimension,double A[],double E,double ro,double Gexp[],int inicio,int fim,double G[],int custo);
void  ruido (double Gexp[], int n, double epslon, int numero_sinais, int ent_sinal);
//double propagacao_de_onda_inv(double G[],double A[], double E, double ro, int n, double divisor)

