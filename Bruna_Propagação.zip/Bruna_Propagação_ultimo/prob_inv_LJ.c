#include "propagacao.h"

void prob_inv_LJ (int n, int posicao[], double oldConfig[], int ponto_inicio1, int fim, int inicio1)
{
    int fDimension, final, estimativainicial, i, ponto_inicio,ponto_fim,np,laco, custo, it;
    double G[500],A[500], Gexp[500], E,ponderacao,config[500],newConfig[500], ro;
    int  x;
    clock_t ini, term;
    FILE *resultados, *saida;

    resultados=fopen("areas_finais.txt","w");
    if (resultados==NULL)
        printf("Arquivo 'areas_finais' com erro.");

    saida=fopen("saida_inverso.txt", "w");
    if (saida==NULL)
        printf("Arquivo 'saida' com erro.");

    for(i=0;i<500;i++)
        G[i]=0.0;

    //para ler, estimativa_inicial=1; para nao ler, estimativa_inicial=0
    estimativainicial=0;

    //ponderacao - aceleracao da convergencia
    ponderacao=1.0;
    E=7.10;

    // PONTO INICIO - PONTO FIM
    ponto_inicio = 3;
    ponto_fim    = n;
    np = 1; //resolve "n" incognitas de cada vez ***************		  n�o entendi muito bem...

    final=ponto_fim;
    ponto_inicio1=ponto_inicio; // ponto inicio1 --- primeiro ponto a ser estimado

    //dados experimentais
    dados_experimentais(Gexp,n,ponderacao, posicao, inicio1);
    //printf ("Dados Experimentais\t");

    //estimativas iniciais
    estimativa_inicial(A,E,ro,n,estimativainicial);
//    printf ("\n Estimativa Inicial \n");

    
    //pontos iniciais
    ponto_fim=(ponto_inicio-1)+(np);
    n=ponto_fim;
    fDimension=n;
    laco=3;


    ro=2700;
    //custo=0;
    printf("foi\n");
    ini = clock();
    while (laco<=(final))
    {
    printf("laco %d de %d\n", laco, final);
    //printf ("Inserindo dados nos arquivos: \n");
    //printf (" 'resultadofinal_inverso.txt', 'custo_inverso.txt' e 'saida_inverso.txt' \n \n");
    //printf ("Este processo pode ser um pouco demorado. \n");
    //printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n");
    //fprintf(resultados,"\n LACO----------- %d \t -- \t %d \t %d \n",laco,ponto_inicio,ponto_fim);
    //printf("Laco: %d \t %d \t %d \t \n", laco, ponto_inicio, ponto_fim);

	//fprintf(resultados, "*************** \n");



    //fprintf(saida, "");
    fprintf(saida, "\n Parametro %d \n", laco);
    //printf("Parametro %d \n", laco);
	fprintf(saida, "*************** \t Gexp= %lf \n",Gexp[laco]);
	fclose (saida);

	saida=fopen("saida_inverso.txt","w");
	if (saida==NULL)
        printf ("Erro em saida");

	//printf ("*********** \t Gexp=%lf \n", Gexp[laco]);

    for(i=0; i<=n; i++)
    {
        config[i]=(A[i]/A[1]);
        oldConfig[i]=config[i];
		newConfig[i]=config[i];
		
    }

	custo=0;

    //system("pause");

	LJ(fDimension,posicao, oldConfig,newConfig,A,E,ro,Gexp,ponto_inicio,ponto_fim,laco,G,ponto_inicio1,custo);

    for (i=ponto_inicio; i<=ponto_fim; i++)
		A[i]=oldConfig[i]*300.0;


	//atualizacao para nova iteracao
	ponto_inicio=((ponto_inicio)+(np));
	ponto_fim=((ponto_inicio-1)+(np));
	n=ponto_fim;
	fDimension=n;
	laco=ponto_inicio;
    
    //system("cls");
    }
    term = clock();

    fclose (saida);
    resultados=fopen("areas_finais.txt", "w");
    
    fprintf(resultados, "Posicao na barra(mm) \t\t �rea(mm�) \n");
    for (it=ponto_inicio1; it<n;it++)
        fprintf (resultados, "\t %d  \t\t\t %.15e \n", posicao[it], oldConfig[it]);
    fprintf(resultados, "Tempo de execu��o: %lf\n", (double)(term-ini)/((double)(CLOCKS_PER_SEC)));
    fclose (resultados);

}
