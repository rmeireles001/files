#include "propagacao.h"

void prob_inv_LJ (int n, int posicao[], double oldConfig[], int ponto_inicio1, int fim, int inicio1)
{
    int fDimension, final, estimativainicial, i, ponto_inicio,ponto_fim,np,laco, custo, it;
    double G[500],A[500], Gexp[500], E,ponderacao,config[500],newConfig[500], ro;
    int  x;
    double *Z, *R,*F, *P, **A1, **B1, **Y;
    FILE *resultados, *saida;
    //init_vectors(500, Z, R, F, P, A1, B1, Y);


    Z = (double *) malloc(sizeof(double)*502);
    R = (double *) malloc(sizeof(double)*502);
    F = (double *) malloc(sizeof(double)*500);
    P = (double *) malloc(sizeof(double)*500);
    if(Z==NULL){
        printf("mem�ria insuficente\n");
        exit(1);
    }
    for(i=0; i<500; i++){
        Z[i] = 0;
        R[i] = 0;
        F[i] = 0;
        P[i] = 0;
    }


    A1 = (double **) malloc(sizeof(double *)*502);
    B1 = (double **) malloc(sizeof(double *)*502);
    Y = (double **) malloc(sizeof(double *)*502);
    for(i=0; i<n; i++){
        A1[i] = (double *) malloc(sizeof(double)*502);
        B1[i] = (double *) malloc(sizeof(double)*502);
        Y[i] = (double *) malloc(sizeof(double)*502);
    }


    resultados=fopen("areas_finais.txt","w");
    if (resultados==NULL)
        printf("Arquivo 'areas_finais' com erro.");

    saida=fopen("saida_inverso.txt", "w");
    if (saida==NULL)
        printf("Arquivo 'saida' com erro.");

    for(i=0;i<500;i++)
        G[i]=0.0;



    B1[0][0] = 22;
    printf("foi\n");
    for(i=0; i<10; i++){
        printf("%lf\n", A1[i][i]);
    }
    printf("foi\n");
    //para ler, estimativa_inicial=1; para nao ler, estimativa_inicial=0
    estimativainicial=0;

    //ponderacao - aceleracao da convergencia
    ponderacao=1.0;
    E=7.10;

    // PONTO INICIO - PONTO FIM
    ponto_inicio = 3;
    ponto_fim    = n;
    np = 1; //resolve "n" incognitas de cada vez ***************		  n�o entendi muito bem...

    final=ponto_fim;
    ponto_inicio1=ponto_inicio; // ponto inicio1 --- primeiro ponto a ser estimado

    //dados experimentais
    dados_experimentais(Gexp,n,ponderacao, posicao, inicio1);
    //printf ("Dados Experimentais\t");

    //estimativas iniciais
    estimativa_inicial(A,E,ro,n,estimativainicial);
//    printf ("\n Estimativa Inicial \n");

    
    //pontos iniciais
    ponto_fim=(ponto_inicio-1)+(np);
    n=ponto_fim;
    fDimension=n;
    laco=3;


    ro=2700;
    //custo=0;

    while (laco<=(final))
    {
    printf("%d de %d\n", laco, final);
    //printf ("Inserindo dados nos arquivos: \n");
    //printf (" 'resultadofinal_inverso.txt', 'custo_inverso.txt' e 'saida_inverso.txt' \n \n");
    //printf ("Este processo pode ser um pouco demorado. \n");
    //printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n");
    //fprintf(resultados,"\n LACO----------- %d \t -- \t %d \t %d \n",laco,ponto_inicio,ponto_fim);
    //printf("Laco: %d \t %d \t %d \t \n", laco, ponto_inicio, ponto_fim);

	//fprintf(resultados, "*************** \n");
    fclose (resultados);

    resultados=fopen("areas_finais.txt","w");
    if (resultados==NULL)
        printf("Erro em resultados");

    //fprintf(saida, "");
    fprintf(saida, "\n Parametro %d \n", laco);
    //printf("Parametro %d \n", laco);
	fprintf(saida, "*************** \t Gexp= %lf \n",Gexp[laco]);
	fclose (saida);

	saida=fopen("saida_inverso.txt","w");
	if (saida==NULL)
        printf ("Erro em saida");

	//printf ("*********** \t Gexp=%lf \n", Gexp[laco]);

    for(i=0; i<=n; i++)
    {
        config[i]=(A[i]/A[1]);
        oldConfig[i]=config[i];
		newConfig[i]=config[i];
		
    }

	custo=0;

    //system("pause");

	LJ(fDimension,posicao, oldConfig,newConfig,A,E,ro,Gexp,ponto_inicio,ponto_fim,laco,G,ponto_inicio1,custo, Z, R, F, P, A1, B1, Y);
    for (i=ponto_inicio; i<=ponto_fim; i++)
		A[i]=oldConfig[i]*300.0;


	//atualizacao para nova iteracao
	ponto_inicio=((ponto_inicio)+(np));
	ponto_fim=((ponto_inicio-1)+(np));
	n=ponto_fim;
	fDimension=n;
	laco=ponto_inicio;
    
    //system("cls");
    }

    fclose (saida);
    fclose (resultados);
    resultados=fopen("areas_finais.txt", "w");
    
    fprintf(resultados, "Posicao na barra(mm) \t\t �rea(mm�) \n");
    for (it=ponto_inicio1; it<n;it++)
        fprintf (resultados, "\t %d  \t\t\t %.15e \n", posicao[it], oldConfig[it]);
     
    fclose (resultados);
    liberar(500, Z, R, F, P, A1, B1, Y);

}

void init_vectors(int n, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y){
    Z = alocar_double(n);
    R = alocar_double(n);
    F = alocar_double(n);
    P = alocar_double(n);
    A1 = alocar_matriz(n);
    B1 = alocar_matriz(n);
    Y = alocar_matriz(n);
}

int *alocar_int(int n){
    int *novo = (int *) malloc(sizeof(int)*n);
    int i;
    if(novo==NULL){
        printf("mem�ria insuficente\n");
        exit(1);
    }
    for(i=0; i<n; i++){
        novo[i] = 0;
    }
    return novo;
}

double *alocar_double(double n){
    double *novo = (double *) malloc(sizeof(double)*n);
    int i;
    if(novo==NULL){
        printf("mem�ria insuficente\n");
        exit(1);
    }
    for(i=0; i<n; i++){
        novo[i] = 0;
    }
    return novo;
}

double **alocar_matriz(double n){
    double **novo = (double **) malloc(sizeof(double *)*n);
    int i;
    if(novo==NULL){
        printf("mem�ria insuficente\n");
        exit(1);
    }
    for(i=0; i<n; i++){
        novo[i] = (double *) malloc(sizeof(double)*n);
        if(novo[i]==NULL){
            printf("Mem�ria insuficente\n");
            exit(1);
        }
    }
    return novo;
}

void liberar_matriz(double n, double **matriz){
    int i;
    for(i=0; i<n; i++){
        free(matriz[i]);
    }
    free(matriz);
}

void liberar(double n, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y){
    free(Z);
    free(R);
    free(F);
    free(P);
    liberar_matriz(n, A1);
    liberar_matriz(n, B1);
    liberar_matriz(n, Y);
}