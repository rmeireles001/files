#include "propagacao.h"


int main ()
{
    int n, opcao, i, j, custo, op, posicao[500], ponto_inicio1, fim, inicio1, final, k, opp; 
    double G[1000][3], oldConfig[500];    
    FILE *entrada, *arq_custo, *resultados, *saida;
    char lixo[100];
    
    arq_custo=fopen("custo_inverso.txt", "w");
    if (arq_custo==NULL) printf("ERRO, ARQUIVO CUSTO_LJ");
    fclose (arq_custo);

    saida=fopen ("saida_inverso.txt", "w");
    if (saida==NULL)
        printf("ERRO! Saida_LJ2");
        
    fprintf(arq_custo,"");
    fprintf(arq_custo, "\n Numero de Iteracoes, Funcao Custo, Inicial, Final \n");

    
    opcao=555;
    
    do 
    {
        system ("cls");   
        printf ("----------------------- PROPAGACAO DE ONDAS EM BARRAS ------------------------- \n");
        printf ("\n \t \t ---------------------------------------------- \n ");
        printf (" \t \t ---------------------------------------------- \n");
        printf ("\t \t   1) Problema Direto                     \n");
        printf ("\t \t   2) Problema Direto com analise de ruido\n");
        printf ("\t \t   3) Problema Inverso                    \n");
        printf ("\t \t   4) Sair                                \n");
        printf("\t \t ----------------------------------------------- \n");
        printf("\t \t ----------------------------------------------- \n");
        printf ("\t \t   Digite sua opcao:                      ");
        scanf ("%d", &opcao);       
        while ((opcao<1) || (opcao>4)) 
        {
           printf ("\t\t             Opcao INVALIDA!              \n");
           printf ("\t\t  Digite um valor dentre as opcoes acima. \n \t");
           scanf ("%d", &opcao);
        }
    
        if (opcao==1)  
        {
           op=1;
           system ("cls");
           printf ("Insira os dados no arquivo de entrada 'areas.txt'.\nApos isso: ");
           system ("pause");
           system ("cls");
           entrada=fopen("areas.txt", "r");
           if (entrada==NULL){
              printf ("O arquivo nao foi inserido. Reinicie o programa. \n");
              break;
           }
           else
               printf ("Arquivo inserido com sucesso. \n");
           system ("pause");
           system ("cls");
           printf ("Inserindo dados no arquivo 'eco.txt' \n \n");  
           printf ("Este processo pode ser um pouco demorado. \n");
           printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n \n");                           
           propagacao_de_onda(1);
           fclose (entrada);
        }
        
        if (opcao==2)  
        {
           op=1;
           system ("cls");
           printf ("Insira os dados no arquivo de entrada 'areas.txt'.\nApos isso: ");
           system ("pause");
           system ("cls");
           entrada=fopen("areas.txt", "r");
           if (entrada==NULL){
              printf ("O arquivo nao foi inserido. Reinicie o programa. \n");
              break;
           }
           else
               printf ("Arquivo inserido com sucesso. \n");
           system ("pause");
           system ("cls");
           printf ("Inserindo dados no arquivo 'eco.txt' \n \n");  
           printf ("Este processo pode ser um pouco demorado. \n");
           printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n \n");                           
           propagacao_de_onda(2);
           fclose (entrada);
        }
        
        if (opcao==3)
        {
           system ("cls");
           if (op==1)
           {
              printf ("Um arquivo 'eco.txt' ja foi gerado anteriormente. Deseja continuar com este? \n 1) Sim \n 2) Nao \n");
              scanf("%d", &opp);
           }
           else
           {
              system ("cls");
              printf ("Insira os dados no arquivo de entrada 'eco.txt'.\nApos isso: ");
              system ("pause");
              system ("cls");
              entrada=fopen("eco.txt", "r");
              if (entrada==NULL){
                 printf ("O arquivo nao foi inserido. Reinicie o programa. \n");
                 break;
              }
              else
                  printf ("Arquivo inserido com sucesso. \n");
              system ("pause");
              system ("cls");
           }
              
           if (opp==2)
           {
              system ("cls");
              printf("Insira os dados no arquivo de entrada 'eco.txt'. \n");
              system ("pause");
              entrada=fopen("eco.txt", "r");
              if (entrada==NULL){
                 printf ("O arquivo nao foi inserido. Reinicie o programa. \n");
                 break;
              }
              else
                  printf("Arquivo inserido com sucesso. \n");                
                  
              system("pause");
              system ("cls");
           }
           
          for(i=1;i<1001;i++)
             fscanf(entrada, "%lf %lf %lf", &G[i][1], &G[i][2], &G[i][3]);

           printf ("Posicao inicial: \n");
           scanf("%d", &inicio1);

           //for(i=1;i<1001;i++)
             //  printf("%lf \t %lf \t %lf \n", G[i][1], G[i][2], G[i][3]);
               
           //printf("%lf \t %lf", G[inicio1][3], G[inicio1+1][3]);
           
          /* if (((G[inicio1][3]) && (G[inicio1+1][3])) != 0.000000000000000e+000)
           {
              k=0;
              while (k==0)                                      
              {
                 printf ("Posicao inicial invalida. \n Entre com outra posicao. \n");
                 scanf("%d", &inicio1);
                 fscanf(entrada, "%lf %lf", &G[inicio1][3], &G[inicio1+1][3]);
                 
                 if (((G[inicio1][3]) && (G[inicio1+1][3])) == 0.000000000000000e+000)
                    k=1;
              }
           }
           else
               k=1;  */
           
           printf ("Posicao final: \n");
           scanf("%d", &final);
           n=final-inicio1+1;
           system ("cls");
           printf ("Inserindo dados nos arquivos: \n");
           printf (" 'areas_finais.txt', 'custo_inverso.txt' e 'saida_inverso.txt' \n \n");
           printf ("Este processo pode ser um pouco demorado. \n");
           printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n");
           prob_inv_LJ(n+2, posicao, oldConfig, ponto_inicio1, fim, inicio1);
           printf(" \nDados inseridos com sucesso. \n");
           system("pause");           
        }
    } while (opcao!=4);

//    system ("pause");
    
    fclose(arq_custo);
    fclose (saida);
    fclose (entrada);
    return;
}


