#include "propagacao.h"

void dados_experimentais (double Gexp[], int n, double ponderacao, int posicao[], int inicio1)
{

    int i, j, aux1[1000];
    double aux2[1000], tempo[500], aux;

    FILE *saida,*entrada;

    saida=fopen("saida_inverso.txt", "w");
    if (saida==NULL)
        printf("ERRO! ARQUIVO SAIDA_LJ2");
        
    entrada=fopen("eco.txt", "r");
    if (entrada== NULL)
       printf ("ERRO! Arquivo entrada");
       
    for (i=1; i<pontos; i++)
        fscanf (entrada, "%d %lf %lf", &aux1[i], &aux, &aux2[i]);
   
    j=3; 
    for (i=inicio1;i<=(inicio1+n-3);i++)
    {
        Gexp[j]=aux2[i];
        posicao[j]=i;
        j=j+1;
    }
    
    Gexp[1]=aux2[inicio1-2];
    posicao[1]=aux1[inicio1-2];
    Gexp[2]=aux2[inicio1-1];
    posicao[2]=aux1[inicio1-1];
    
    for (i=1;i<=n;i++)
    {
        Gexp[i]=(Gexp[i]*ponderacao);
        //printf ("Gexp= %lf", Gexp[i]);
        //posicao[i]=((VEL*tempo[i])/(2000));
        //printf("posicao= %d \n", posicao[i]);
        //system ("pause")        ;
    }
        
        
 	fprintf(saida, "--------------- \n");

    fclose(saida);
    fclose(entrada);
    
}
