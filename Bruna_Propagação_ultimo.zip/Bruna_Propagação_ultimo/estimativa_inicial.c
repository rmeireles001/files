#include "propagacao.h"

void estimativa_inicial (double A[],double E, double ro, int n, int estimativainicial)
{
    int i,j;

    FILE *resultados, *estimativa;

    resultados=fopen("areas_finais.txt", "w");
    if (resultados==NULL)
        printf("ERRO! ARQUIVO RESULTADOS_LJ2");

    
    E = 71 * pow(10,9);
    ro = 2700;

    for (i=0;i<=n;i++)
    {
        A[i]=300.0;
    }

    //fprintf(resultados, "Estimativa Inicial ---- \n");
    
    //for (i=1;i<=n;i++)
    //{
    //    fprintf(resultados, "%d \t %lf \n", i, A[i]/300);
    // }


   // fprintf (resultados, "------------------------ \n");
    //fprintf (resultados, " ");

    fclose(resultados);

}
