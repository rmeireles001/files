#include "propagacao.h"

double Q(double config[],int fDimension,double A[],double E,double ro,double Gexp[],int inicio,int fim,double G[],int custo, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y)
{
    int i;
    double Q,divisor;

    FILE *saida;

    saida=fopen("saida_inverso.txt", "w");
    if (saida==NULL) printf("Erro em arquivo 'saida'!");

    custo=custo-1;

    divisor=A[1];

    prop_onda2(G, config, E, ro, fDimension, divisor, Z, R, F, P, A1, B1, Y);


    Q=0.0;
    for (i=inicio; i<=fim; i++)
    {
        Q = Q + ( (G[i] - Gexp[i]) * (G[i] - Gexp[i]));
    }

    fprintf(saida, "\t %d \t %lf \t %lf \n", custo+2, Q, G[inicio]);
   // printf ("Inserindo dados nos arquivos: \n");
   // printf (" 'resultadofinal_inverso.txt', 'custo_inverso.txt' e 'saida_inverso.txt' \n \n");
   // printf ("Este processo pode ser um pouco demorado. \n");
   // printf ("Por favor, aguarde ate aparecer uma mensagem informando o termino da insercao   dos dados. \n");
    //printf("%d \t %lf \t %lf", custo+2, Q, G[inicio]);
    //system("cls");
    fclose(saida);

    return Q;
}
