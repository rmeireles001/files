#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#define VEL 5128.0
#define LARG 30.0 /*em mm*/
#define RO 2700.0
#define pontos 1001 //discretiza��o
#define ALTURA 10.0
#define myrand ((double)(rand())/(double)(RAND_MAX)) //macro
#define MAX 2
void propagacao_de_onda (int op);
void prop_onda (double G[],double A[], double E, double ro, int n, double divisor); 
void prop_onda2(double G[],double A[], double E, double ro, int n, double divisor, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y);
void prob_inv_LJ(int n, int posicao[], double oldConfig[], int ponto_inicio1, int fim, int inicio1);
void estimativa_inicial (double A[], double E, double ro, int n, int estimativainicial);
void dados_experimentais (double Gexp[], int n, double ponderacao, int posicao[], int inicio1);
void LJ(int fDimension, int posicao[],double oldConfig[],double newConfig[],double A[],double E,double ro,double Gexp[],int inicio,int fim,int laco,double G[],int ponto_inicio1,int custo, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y);
double Q(double config[],int fDimension,double A[],double E,double ro,double Gexp[],int inicio,int fim,double G[],int custo, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y);
void  ruido (double Gexp[], int n, double epslon, int numero_sinais, int ent_sinal);
//double propagacao_de_onda_inv(double G[],double A[], double E, double ro, int n, double divisor)

void init_vectors(int n, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y);
double *alocar_double(double n);
double **alocar_matriz(double n);
void liberar_matriz(double n, double **matriz);
void liberar(double n, double *Z, double *R, double *F, double *P, double **A1, double **B1, double **Y);

