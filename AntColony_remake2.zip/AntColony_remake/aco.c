
#include"dec.h"
#include"func.h"
//#include <time.h>

void ant_colony(double *G, double *A, double *Gexp, double *config, double **A1, double **B1, double **Y, double *Z, double *R, double *F, double *P, int *posicao)
{
	int runno, itno, antno;
	double time_used;
		printf("foi\n");
	read_data(inpfname);
	//print_data();
	init_out(inpfname);

	for(runno=0; runno<runs; runno++){
		seed = (long int) time(NULL);
		start_timers();
		initialize_ants_variables(runno);
		initialize_trail();

		for(itno=0; bestant.ofn != 436.00 && itno<ncmax; itno++){
			iteration_init(itno);
			find_values();
			analysis(itno, G, A, Gexp,  config, A1, B1, Y, Z, R, F, P, posicao);
			update_stats(itno, runno);
			#if(usels==1)
			if(lswithitbest==1){
				ls(&itbestval, itno, G, A, Gexp,  config, A1, B1, Y, Z, R, F, P, posicao);
				lsstats(itno, runno);
			}
			if(lswithbest==1){
				ls(&bestval, itno, G, A, Gexp,  config, A1, B1, Y, Z, R, F, P, posicao);
				lsstats(itno, runno);
			}
			#endif
			trail();

				print_itstats(itno, runno);
		}
		update_stats(itno, runno);
		report_run(runno);
	}
	final_stats();
}

int main(int argc, char *argv[])
{
	double *G, *A, *Gexp,  *config, **A1, **B1, **Y, *Z, *R, *F, *P;
	int *posicao;
	int pi = 0, final = 0, laco=3, i = 0, k = 0, j = 0, nt = 0;
	inpfname = argv[1];
	estimativainicial = 0;
	ponderacao = 1.0;
	E = 71 * pow(10,9);
    ro = 2700;
	n = fim-inicio+3;
	nt = n;
	init_vectors(n+1, G, A, Gexp,  config, A1, B1, Y, Z, R, F, P, posicao);
	pinicio = 3;
	pfim = n;
	pi = pinicio;
	final = pfim;
	inserir_dados(n, inicio, Gexp, posicao);
	printf("foi\n");
	estimativa_inicial(A, n+1);
	FILE *test;

	pfim = (pinicio-1)+np;
	n=pfim;
	fdimension=n; //É alterado posteriormente

	while(laco<=final){
		printf("laco %d de %d\n", laco, final);
		for(i=0; i<=n; i++) {
			config[i] = A[i]/A[1];
		}

		ant_colony(G, A, Gexp,  config, A1, B1, Y, Z, R, F, P, posicao);

		for(i=0, k=pinicio;k<=pfim; k++, i++){
			config[k]=bestval.var[i];
		}

		for(i=pinicio; i<=pfim; i++) {
			A[i]=config[i]*300;
		}

		pinicio+=np;
		pfim = pinicio-1+np;
		n=pfim;
		fdimension=n;
		laco = pinicio;
	}

	/*test = fopen("test.txt", "w");
for(i=0; i<=nt; i++){
		fprintf(test, "%.15e %d\n", Gexp[i], posicao[i]);
	}
	fclose(test);*/
	liberar(nt, G, A, Gexp,  config, A1, B1, Y, Z, R, F, P, posicao);
	FILE *resultados = fopen("areas.txt", "w");
	fprintf(resultados, "Posição (mm)\t\tÁrea(mm²)\n");
	for(i=pi; i<n; i++){
		fprintf(resultados, "%d\t\t%.15e\n", posicao[i], config[i]);
	}
	fclose(resultados);
	return 0;
}

void init_vectors(int n, double *G, double *A, double *Gexp, double *config, double **A1, double **B1, double **Y, double *Z, double *R, double *F, double *P, int *posicao){
	G = alocar_double(n);
	Gexp = alocar_double(n);
	A = alocar_double(n);
	config = alocar_double(n);
	posicao = alocar_int(n);
	Z = alocar_double(n);
	R = alocar_double(n);
	F = alocar_double(n);
	P = alocar_double(n);
	A1 = alocar_matriz(n);
	B1 = alocar_matriz(n);
	Y = alocar_matriz(n);
}

int *alocar_int(int n){
	int *novo = (int *) malloc(sizeof(int)*n);
	int i;
	if(novo==NULL){
		printf("memória insuficente\n");
		exit(1);
	}
	for(i=0; i<n; i++){
		novo[i] = 0;
	}
	return novo;
}

double *alocar_double(double n){
	double *novo = (double *) malloc(sizeof(double)*n);
	int i;
	if(novo==NULL){
		printf("memória insuficente\n");
		exit(1);
	}
	for(i=0; i<n; i++){
		novo[i] = 0;
	}
	return novo;
}

double **alocar_matriz(double n){
	double **novo = (double **) malloc(sizeof(double *)*n);
	int i;
	if(novo==NULL){
		printf("memória insuficente\n");
		exit(1);
	}
	for(i=0; i<n; i++){
		novo[i] = (double *) malloc(sizeof(double)*n);
		if(novo[i]==NULL){
			printf("Memória insuficente\n");
			exit(1);
		}
	}
	return novo;
}

void liberar_matriz(double n, double **matriz){
	int i;
	for(i=0; i<n; i++){
		free(matriz[i]);
	}
	free(matriz);
}

void liberar(double n, double *G, double *A, double *Gexp, double *config, double **A1, double **B1, double **Y, double *Z, double *R, double *F, double *P, int *posicao){
	free(G);
	free(Gexp);
	free(A);
	free(config);
	free(posicao);
	free(Z);
	free(R);
	free(F);
	free(P);
	liberar_matriz(n, A1);
	liberar_matriz(n, B1);
	liberar_matriz(n, Y);
}
