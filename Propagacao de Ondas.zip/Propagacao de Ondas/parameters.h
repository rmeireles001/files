#define ANTS 20
#define ncmax 15
#define runs 1
#define gamma 0.1
#define rho 0.1

//Other constants
#define LSANTS 25
#define lsncmax  15
#define lsnvalues 2
#define lsrho 0.5
#define tau0 1
#define ras_ranks 5
#define q0 0.0
#define localupdate 1
#define alpha 1