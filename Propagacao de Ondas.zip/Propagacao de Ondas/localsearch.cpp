#include "localsearch.h"


void localsearch::lsget_data(values *gvalptr){
	int vno;
}