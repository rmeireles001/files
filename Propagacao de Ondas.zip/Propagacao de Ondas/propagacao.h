#ifndef prop_onda
#define prop_onda

#define ponderacao 1.0
#define ro 2700
#define pontos 1001

#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

class propagacao{
public:
	double *Gexp, *G, *A, *Z, *R, *F, *P, *posicao, *config;
	double **A1, **B1, **Y;
	double E, c;
	propagacao();
	~propagacao();
	double **alocar_mat(int size);
	void liberar_mat(double **mat, int size);
	void inserir(string s);
	void prob_direto(int n, double *A, double *G);
	void prob_inverso();
	void prob_inverso(int n, double *A);
	double erroG(int i);
	void atribuirA(int n, double v);
	void dados_experimentais(string s, int n, int ini);
	void estimativa_inicial(double n);
	void config_area(double n);
	void attr_config(int k, double var);
	void atualizar_area(int k);
	void zerar(int n);
};

#endif