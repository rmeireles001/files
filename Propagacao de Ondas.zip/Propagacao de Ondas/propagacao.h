#ifndef prop_onda
#define prop_onda

#define ponderacao 1.0
#define ro 2700
#define pontos 1001

#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

class propagacao{
public:
	double *Gexp, *G, *A, *Z, *R, *F, *P, *posicao;
	double **A1, **B1, **Y;
	double E, c;
	propagacao();
	~propagacao();
	double **alocar_mat(int size);
	void liberar_mat(double **mat, int size);
	void inserir(string s);
	void prob_direto(double *fG, int n);
	void prob_inverso();
	void prob_inverso(int n);
	double erroG(int i);
	void atribuirA(int n, double v);
};

#endif