#ifndef localsearch_h
#define localsearch_h

#include <iostream>
#include "parameters.h"
#include "ant.h"
#include "variable.h"
#include "values.h"

using namespace std;

class localsearch{
	variable *var;
	ants *ant, *bestant, *itbestant, *itworstant;
	values *itbestval, *itworstval, *bestval;
	void lsget_data(values *gvalptr)
};

#endif