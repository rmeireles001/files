#include <iostream>
#include <cstdio>
#include "propagacao.h"
#include "aco.h"

using namespace std;

int main(){
	propagacao p;
	p.inserir("areas.txt");
	/*p.prob_inverso();
	for(int i=3; i<=1000; i++){
		p.prob_inverso(i);
	}*/
	p.prob_direto(p.Gexp, 1000);
	p.atribuirA(0, 1);
	p.atribuirA(1, 1);
	p.atribuirA(2, 1);
	for(int i=3; i<=1000; i++){
		p.atribuirA(i, 0);
	}
	p.prob_inverso();
	aco a;
	a.get_data(1, 1, 0.05);
	srand(time(NULL));
	for(int i=3; i<=23; i++){
		cout << i << endl;
		a.run(i, &p);
		p.atribuirA(i, a.get_var());
	}
	a.end();
	FILE *f = fopen("areas_inverso.txt", "w");
	for(int i=1; i<=23; i++){
		fprintf(f, "%4.0lf\t%.15e\n", p.posicao[i], p.A[i]);
	}
	fclose(f);
	return 0;
}