#include <iostream>
#include <cstdio>
#include "propagacao.h"
#include "aco.h"

#define inicio 480
#define fim 520

using namespace std;

/*int main(){
	int n = fim-inicio+3;
	int laco;
	propagacao p;
	srand(time(NULL));
	p.dados_experimentais("eco.txt", n, inicio);
	p.estimativa_inicial(n);
	aco a;
	a.get_data(0,1,0.05);
	//a.run(2, &p);
	laco = 3;
	while(laco<=n){
		p.config_area(laco);
		a.run(laco, &p);
		p.attr_config(laco, a.get_var());
		p.atualizar_area(laco);
		cout << p.posicao[laco] << "   " << p.config[laco] << endl;
		laco++;
	}
	a.end();
	for(int i=3; i<=n; i++){
		cout << p.posicao[i] << "   " << p.config[i] << endl;
	}
	return 0;
}*/

int main(){
	clock_t start, end;
	aco a;
	propagacao p;
	srand(time(NULL));
	p.inserir("areas.txt");
	p.prob_direto(1000, p.A, p.Gexp);
	p.prob_direto(480, p.A, p.G);
	a.get_data(0,1,0.05);
	start = clock();
	for(int i=inicio; i<=fim; i++){
		a.run(i, &p);
		p.attr_config(i, a.get_var());
		p.prob_inverso(i, p.config);
		cout << p.posicao[i] << "   " << p.config[i] << endl;
	}
	end = clock();
	FILE *resultados = fopen("areas_inverso.txt", "w");
	for(int i=inicio; i<=fim; i++){
		fprintf(resultados, "%d\t\t%.15e\n", (int) p.posicao[i], p.config[i]);
	}
	fprintf(resultados, "Tempo gasto: %lf\n", (double)(end-start)/(double)(CLOCKS_PER_SEC));
	fclose(resultados);
	a.end();
}