
#include"dec.h"
#include"func.h"
//#include <time.h>

void ant_colony()
{
	int runno, itno, antno;
	double time_used;
	read_data(inpfname);
	//print_data();
	init_out(inpfname);

	for(runno=0; runno<runs; runno++){
		seed = (long int) time(NULL);
		
		start_timers();
		initialize_ants_variables(runno);
		initialize_trail();

		for(itno=0; bestant.ofn != 436.00 && itno<ncmax; itno++){
			iteration_init(itno);
			find_values();
			analysis(itno);
			update_stats(itno, runno);
			#if(usels==1)
			if(lswithitbest==1){
				ls(&itbestval, itno);
				lsstats(itno, runno);
			}
			if(lswithbest==1){
				ls(&bestval, itno);
				lsstats(itno, runno);
			}
			#endif
			trail();

			if(!(itno%statsafterit))
				print_itstats(itno, runno);
		}
		update_stats(itno, runno);
		report_run(runno);
	}
	final_stats();
}

int main(int argc, char *argv[])
{
	int pi, final, laco=3, i, k, j, nt;
	inpfname = argv[1];
	estimativainicial = 0;
	ponderacao = 1.0;
	E = 71 * pow(10,9);
    ro = 2700;
	n = fim-inicio+3;
	nt = n;
	init_vectors(n+1);
	pinicio = 3;
	pfim = n;
	pi = pinicio;
	final = pfim;
	dados_experimentais(Gexp, posicao, n, inicio);
	estimativa_inicial(A, n+1);
	pfim = (pinicio-1)+np;
	n=pfim;
	fdimension=n; //É alterado posteriormente
	FILE *resultados = fopen("areas.txt", "w");
	fprintf(resultados, "Posição (mm)\t\tÁrea(mm²)\n");
	fclose(resultados);
	/*while(laco<=final){
		for(i=0; i<=n; i++)
			config[i] = A[i]/A[1];
		printf("foi\n");
		ant_colony();
		resultados = fopen("areas.txt", "a");
		for(i=0, k=pinicio;k<=pfim; k++, i++){
			config[k]=bestval.var[i];
			fprintf(resultados, "%d\t\t%.15e\n", posicao[i], config[i]);
		}
		fclose(resultados);
		
		for(i=pinicio; i<=pfim; i++)
			A[i]=config[i]*300;
		pinicio+=np;
		pfim = pinicio-1+np;
		n=pfim;
		fdimension=n;
		laco = pinicio;
	}*/
	liberar(nt);
	/*FILE *resultados = fopen("areas.txt", "w");
	fprintf(resultados, "Posição (mm)\t\tÁrea(mm²)\n");
	for(i=pi; i<n; i++){
		fprintf(resultados, "%d\t\t%.15e\n", posicao[i], config[i]);
	}
	fclose(resultados);*/
	return 0;
}

void init_vectors(int n){
	G = alocar_double(n);
	Gexp = alocar_double(n);
	A = alocar_double(n);
	config = alocar_double(n);
	posicao = alocar_int(n);
	Z = alocar_double(n);
	R = alocar_double(n);
	F = alocar_double(n);
	P = alocar_double(n);
	A1 = alocar_matriz(n);
	B1 = alocar_matriz(n);
	Y = alocar_matriz(n);
}

int *alocar_int(int n){
	int *novo = (int *) malloc(sizeof(int)*n);
	int i;
	if(novo==NULL){
		printf("memória insuficente\n");
		exit(1);
	}
	for(i=0; i<n; i++){
		novo[i] = 0;
	}
	return novo;
}

double *alocar_double(double n){
	double *novo = (double *) malloc(sizeof(double)*n);
	int i;
	if(novo==NULL){
		printf("memória insuficente\n");
		exit(1);
	}
	for(i=0; i<n; i++){
		novo[i] = 0;
	}
	return novo;
}

double **alocar_matriz(double n){
	double **novo = (double **) malloc(sizeof(double *)*n);
	int i;
	if(novo==NULL){
		printf("memória insuficente\n");
		exit(1);
	}
	for(i=0; i<n; i++){
		novo[i] = (double *) malloc(sizeof(double)*n);
		if(novo[i]==NULL){
			printf("Memória insuficente\n");
			exit(1);
		}
	}
	return novo;
}

void liberar_matriz(double n, double **matriz){
	int i;
	for(i=0; i<n; i++){
		free(matriz[i]);
	}
	free(matriz);
}

void liberar(double n){
	free(G);
	free(Gexp);
	free(A);
	free(config);
	free(posicao);
	free(Z);
	free(R);
	free(F);
	free(P);
	liberar_matriz(n, A1);
	liberar_matriz(n, B1);
	liberar_matriz(n, Y);
}