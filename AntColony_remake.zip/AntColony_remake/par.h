#define ANTS  25 
#define ncmax 30 
#define runs 2
#define gamma 0.1 
#define rho    0.1 

