

#include"par.h"
#define LSANTS  25	
#define lsnvalues 2 
#define lsncmax  15
#define precision 4
#define lbt 0 
#define elitist 0  
#define ras 1 
#define taco 0 
#define as 0
#define acs 0
#define usels 1 
#define elitist_ants  1 
#define ras_ranks 5	 
#define lswithbest 1
#define lswithitbest 0
#define nov 1
#define constrained 0
#define tau0 1
// 1-rho has been used as multiplying factor so take 0.2,0.1
#define alpha 1
#define q0 0.0
#define localupdate 1 
#define lsrho 0.5
#define lsalpha 1
#define lstau0 1
#define lsq0 0.0
#define statsafterit 15
#define sharing 0

#define pontos 1001 
#define inicio 200
#define fim 599
#define np 1
